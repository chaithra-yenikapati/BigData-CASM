import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class StubDriver {
	public static void main(String[] args) throws Exception 
	{
		if (args.length != 2) 
		{
			System.err.println("Usage: Driver <input path> <output path>");
			System.exit(-1);
		}
		Job job = new Job();
		job.setJarByClass(StubDriver.class);
		job.setJobName("ETL&Profilling");
		FileInputFormat.setInputDirRecursive(job, true);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setMapperClass(StubMapper.class);
		job.setReducerClass(StubReducer.class);
		job.setMapOutputKeyClass(Text.class); // setting the output key class for the Mapper
		job.setMapOutputValueClass(Text.class); // setting the output value class for the Mapper
		job.setNumReduceTasks(0);
		//job.setOutputKeyClass(LongWritable.class); //setting the output key class for Reducer 
 		//job.setOutputValueClass(Text.class); //setting the output value class for Reducer
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}