import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class StubMapper extends Mapper<LongWritable, Text, Text, Text>
{
	public static String month1[] = {"Jan", "Feb", "Mar", "Apr", "May","Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
    {
    	String record = value.toString();
    	String str[] = record.split(",");
		String date[] = str[0].split("-");
		Map<String, Integer> month= new HashMap<String, Integer>();
		month.put("Jan", 1);
		month.put("Feb", 2);
		month.put("Mar", 3);
		month.put("Apr", 4);
		month.put("May", 5);
		month.put("Jun", 6);
		month.put("Jul", 7);
		month.put("Aug", 8);
		month.put("Sep", 9);
		month.put("Oct", 10);
		month.put("Nov", 11);
		month.put("Dec", 12);
		StringBuilder builder = new StringBuilder();
		for(int i=0;i<date.length;i++)
		{
			builder.append(date[i]);
		}
		String str2 = builder.toString();
		for(int i=0;i<month1.length;i++)
		{
			if(str2.contains(month1[i]))
			{
				builder.delete(0,builder.length());
				int mon = month.get(month1[i]);
				int day = Integer.valueOf(date[0]);
				if(mon <= 9)
				{
					if(day <= 9)
					{
						builder.append("20"+date[2]+"0"+mon+"0"+day);
					}
					else
					{
						builder.append("20"+date[2]+"0"+mon+day);
					}
				}
				else
				{
					if(day <= 9)
					{
						builder.append("20"+date[2]+mon+"0"+day);
					}
					else
					{
						builder.append("20"+date[2]+mon+day);
					}
				}
				str[0] = builder.toString();
			}
		}
		ArrayList<String> arrList = new ArrayList<String>();
		for(int i=0;i<7;i++)
		{
			arrList.add(str[i]);
		}
		arrList.remove(5);
		arrList.trimToSize();
		for(int i=0;i<arrList.size();i++)
		{
			double number = 0;
			if(i != 0)
			{
				number = Double.valueOf(arrList.get(i));
				if(i != 5)
				{
					number = (number/65.0); // making every value to be USD
				}
			}
			if(i > 0)
			{
				String numberStr = String.format("%.2f", number);
				arrList.remove(i);
				arrList.add(i, numberStr);
			}
		}
		builder.delete(0,builder.length());
		for(int i=0;i<arrList.size();i++)
		{	
			if(arrList.get(i).equals(""))
			{
				if(i == 4)
				{
					double mean = (Double.valueOf(arrList.get(2))+Double.valueOf(arrList.get(3)))/2;
					String avg = String.valueOf(mean);
					arrList.remove(i);
					arrList.add(i,avg);
				}
				else
				{
					arrList.remove(i);
					arrList.add(i, "0");
				}
			}
			if(i != arrList.size()-1)
			{
				builder.append(arrList.get(i)+",");
			}
			else
			{
				builder.append(arrList.get(i));
			}
		}
		context.write(new Text(builder.toString()),null);
	}
}

